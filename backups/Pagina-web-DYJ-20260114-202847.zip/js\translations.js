// Translations Object
const translations = {
    es: {
        // Navigation
        nav_inicio: "Inicio",
        nav_servicios: "Servicios",
        nav_casos: "Casos de éxito",
        nav_sobre: "Sobre nosotros",
        nav_politicas: "Políticas",
        nav_contacto: "Contacto",

        // Theme
        theme_dark: "Modo oscuro",
        theme_light: "Modo claro",
        
        // Hero Section (Index)
        hero_title: "Transformamos <span class=\"hero-accent\">datos</span><br><span class=\"highlight\">en decisiones inteligentes</span>",
        hero_subtitle: "Desentrañamos el potencial oculto en sus datos para convertirlos en <span class=\"hero-accent-soft\">estrategias de negocio claras y accionables</span> que impulsan el <span class=\"hero-accent\">crecimiento</span> y la innovación de su empresa",
        hero_cta: "Agenda una reunión gratuita",
        hero_cta2: "Conoce nuestros servicios",
        
        // Services Section
        services_title: "Nuestros Servicios",
        services_subtitle: "Soluciones profesionales de análisis de datos",
        service1_title: "Dashboards Interactivos",
        service1_desc: "Tableros de control personalizados y fáciles de usar para una visualización clara de sus datos clave",
        service2_title: "KPIs Visualizados",
        service2_desc: "Mida el éxito con indicadores claros y comprensibles que impulsan decisiones estratégicas",
        service3_title: "Análisis de Tendencias",
        service3_desc: "Identifique patrones y anticipe el futuro de su mercado con análisis profundos",
        services_cta: "Ver todos los servicios",
        
        // About Section
        about_title: "Quiénes Somos",
        about_text1: "Somos un equipo de <strong>expertos apasionados por los datos</strong>, dedicados a la excelencia en cada proyecto. Nos especializamos en convertir desafíos complejos de datos en oportunidades claras y accionables que impulsan el crecimiento de su negocio.",
        about_text2: "Ofrecemos soluciones personalizadas de análisis y visualización de datos, desde <strong>dashboards interactivos</strong> hasta <strong>reportes ejecutivos</strong>, diseñadas específicamente para satisfacer las necesidades únicas de cada cliente con un enfoque colaborativo.",
        about_cta: "Conoce más sobre nosotros",
        
        // Values Section
        mission_title: "Nuestra Misión",
        value1_title: "Innovación Constante",
        value1_desc: "Nos mantenemos a la vanguardia de las últimas tecnologías y tendencias en análisis de datos. Implementamos soluciones innovadoras que anticipan las necesidades del mercado y transforman la manera en que su empresa entiende y utiliza sus datos para mantener una ventaja competitiva.",
        value2_title: "Calidad y Confiabilidad",
        value2_desc: "Cada proyecto es ejecutado con los más altos estándares de calidad. Nuestros clientes confían en nosotros porque entregamos soluciones precisas, robustas y confiables. Construimos relaciones a largo plazo basadas en la excelencia y el compromiso con resultados excepcionales que superan expectativas.",
        value3_title: "Resultados Medibles",
        value3_desc: "Nos enfocamos en generar impacto real y tangible en su negocio. Cada solución está diseñada para proporcionar métricas claras y accionables que demuestren el valor de nuestro trabajo. Transformamos datos en insights que generan resultados concretos y mejoran el desempeño de su organización.",
        
        // CTA Section
        cta_title: "¿Listo para transformar tus datos en decisiones estratégicas?",
        cta_subtitle: "Agenda una reunión gratuita con nuestro equipo de expertos",
        cta_button: "Agenda una reunión gratuita",
        
        // Footer
        footer_tagline: "Transformamos datos en decisiones estratégicas",
        footer_nav: "Navegación",
        footer_contact: "Contacto",
        footer_legal: "Legal",
        footer_privacy: "Política de Privacidad",
        footer_service: "Política de Servicio",
        footer_terms: "Términos y Condiciones",
        footer_rights: "Todos los derechos reservados.",
        
        // Services Page
        services_page_title: "Nuestros Servicios",
        services_page_subtitle: "Soluciones de análisis de datos diseñadas para impulsar el crecimiento de su empresa",
        services_detail1_title: "Dashboards Interactivos",
        services_detail1_desc: "Tableros de control personalizados y fáciles de usar que transforman datos complejos en visualizaciones claras e intuitivas. Permiten una comprensión instantánea del estado de su negocio y facilitan decisiones informadas en tiempo real.",
        services_detail2_title: "Reportes Automatizados",
        services_detail2_desc: "Informes generados automáticamente que le ahorran tiempo y reducen errores. Reciba reportes detallados y precisos en su bandeja de entrada de manera periódica, permitiendo un seguimiento constante del desempeño sin esfuerzo manual.",
        services_detail3_title: "Análisis de Tendencias",
        services_detail3_desc: "Identifique patrones ocultos en sus datos históricos para anticiparse a las tendencias del mercado. Nuestros análisis profundos revelan oportunidades de crecimiento y le ayudan a tomar decisiones estratégicas proactivas en lugar de reactivas.",
        services_detail4_title: "KPIs Visualizados",
        services_detail4_desc: "Mida el éxito de su negocio con indicadores clave de rendimiento claros, comprensibles y accionables. Transformamos métricas complejas en visualizaciones que comunican el estado de su empresa de forma instantánea y facilitan decisiones estratégicas.",
        
        // Portfolio Page
        portfolio_title: "Casos de Éxito",
        portfolio_subtitle: "Descubre cómo hemos ayudado a empresas a transformar sus datos",
        portfolio1_category: "Retail",
        portfolio1_title: "Dashboard de Ventas y Facturación",
        portfolio1_desc: "Implementación de un sistema completo de análisis de ventas para una cadena retail.",
        portfolio2_category: "Finanzas",
        portfolio2_title: "Control Financiero Ejecutivo",
        portfolio2_desc: "Dashboard ejecutivo para análisis financiero integral.",
        portfolio3_category: "Marketing",
        portfolio3_title: "Analytics de Marketing Digital",
        portfolio3_desc: "Integración de datos de múltiples plataformas digitales.",
        testimonials_title: "Lo que dicen nuestros clientes",
        
        // Contact Page
        contact_title: "Contáctanos",
        contact_subtitle: "Estamos aquí para ayudarte a transformar tus datos",
        contact_form_title: "Envíanos un mensaje",
        contact_name: "Nombre completo",
        contact_email: "Correo electrónico",
        contact_phone: "Teléfono",
        contact_message: "Mensaje",
        contact_submit: "Enviar mensaje",
        contact_info_title: "Información de contacto",
        
        // Policies Page
        policies_title: "Políticas y Documentos Legales",
        policies_subtitle: "Transparencia y compromiso con nuestros clientes",
        policies_intro_title: "Documentación Legal",
        policies_intro_desc: "En D&J Insights Group nos comprometemos con la transparencia y el cumplimiento legal. A continuación, puede consultar y descargar nuestros documentos oficiales:",
        policy1_title: "Políticas de Servicio",
        policy1_desc: "Conoce nuestros términos de servicio, alcance de proyectos, tiempos de entrega y compromisos con nuestros clientes.",
        policy2_title: "Políticas de Privacidad",
        policy2_desc: "Información sobre cómo recopilamos, usamos y protegemos sus datos personales de acuerdo con las normativas vigentes.",
        policy3_title: "Términos y Condiciones",
        policy3_desc: "Términos legales que rigen el uso de nuestros servicios, obligaciones de ambas partes y resolución de conflictos.",
        download_pdf: "Descargar PDF",
        policies_summary: "Resumen de Nuestras Políticas",
        
        // About Page
        about_page_title: "Sobre Nosotros",
        about_page_subtitle: "Conoce al equipo detrás de D&J Insights Group",
        about_story_title: "¿Quiénes somos?",
        about_story_p1: "Somos un <strong>equipo de expertos apasionados por los datos</strong>, dedicados a la excelencia en cada proyecto que emprendemos. Nos especializamos en convertir desafíos complejos de datos en oportunidades claras y accionables que impulsan el crecimiento sostenible de su negocio.",
        about_story_p2: "Ofrecemos <strong>soluciones personalizadas de análisis y visualización de datos</strong>, desde dashboards interactivos hasta reportes ejecutivos, diseñadas específicamente para satisfacer las necesidades únicas de cada cliente.",
        about_story_p3: "Nuestro <strong>enfoque colaborativo</strong> nos permite integrarnos perfectamente con su equipo, entendiendo a fondo su industria y objetivos para entregar soluciones que realmente generen impacto.",
        about_pillars_title: "Nuestros Pilares",
        why_choose_title: "¿Por qué elegirnos?",
        reason1_title: "Expertos Dedicados",
        reason1_desc: "Un equipo especializado y apasionado por los datos, comprometido con la excelencia en cada proyecto y en constante actualización de conocimientos.",
        reason2_title: "Soporte Inquebrantable",
        reason2_desc: "No solo entregamos el proyecto, te acompañamos después para garantizar que saques el máximo provecho.",
        reason3_title: "Tecnología de Vanguardia",
        reason3_desc: "Utilizamos las herramientas más avanzadas en análisis de datos para preparar a nuestros clientes para el futuro digital.",
        reason4_title: "Soluciones Personalizadas",
        reason4_desc: "Cada empresa es única. Diseñamos soluciones adaptadas específicamente a sus objetivos, industria y desafíos particulares.",
        reason5_title: "Impacto Medible",
        reason5_desc: "Cada solución que implementamos genera resultados cuantificables que mejoran el desempeño y crecimiento de su organización.",
    },
    en: {
        // Navigation
        nav_inicio: "Home",
        nav_servicios: "Services",
        nav_casos: "Success Stories",
        nav_sobre: "About Us",
        nav_politicas: "Policies",
        nav_contacto: "Contact",

        // Theme
        theme_dark: "Dark mode",
        theme_light: "Light mode",
        
        // Hero Section (Index)
        hero_title: "We transform <span class=\"hero-accent\">data</span><br><span class=\"highlight\">into intelligent decisions</span>",
        hero_subtitle: "We unravel the hidden potential in your data to convert it into <span class=\"hero-accent-soft\">clear and actionable business strategies</span> that drive <span class=\"hero-accent\">growth</span> and innovation for your company",
        hero_cta: "Schedule a free meeting",
        hero_cta2: "Discover our services",
        
        // Services Section
        services_title: "Our Services",
        services_subtitle: "Professional data analysis solutions",
        service1_title: "Interactive Dashboards",
        service1_desc: "Customized and user-friendly control panels for clear visualization of your key data",
        service2_title: "Visualized KPIs",
        service2_desc: "Measure success with clear and understandable indicators that drive strategic decisions",
        service3_title: "Trend Analysis",
        service3_desc: "Identify patterns and anticipate your market's future with deep analysis",
        services_cta: "View all services",
        
        // About Section
        about_title: "Who We Are",
        about_text1: "We are a team of <strong>data-passionate experts</strong>, dedicated to excellence in every project. We specialize in turning complex data challenges into clear and actionable opportunities that drive your business growth.",
        about_text2: "We offer customized data analysis and visualization solutions, from <strong>interactive dashboards</strong> to <strong>executive reports</strong>, specifically designed to meet each client's unique needs with a collaborative approach.",
        about_cta: "Learn more about us",
        
        // Values Section
        mission_title: "Our Mission",
        value1_title: "Constant Innovation",
        value1_desc: "We stay at the forefront of the latest technologies and trends in data analysis. We implement innovative solutions that anticipate market needs and transform how your company understands and uses its data to maintain a competitive edge.",
        value2_title: "Quality and Reliability",
        value2_desc: "Every project is executed with the highest quality standards. Our clients trust us because we deliver precise, robust, and reliable solutions. We build long-term relationships based on excellence and commitment to exceptional results that exceed expectations.",
        value3_title: "Measurable Results",
        value3_desc: "We focus on generating real and tangible impact on your business. Every solution is designed to provide clear and actionable metrics that demonstrate the value of our work. We transform data into insights that generate concrete results and improve your organization's performance.",
        
        // CTA Section
        cta_title: "Ready to transform your data into strategic decisions?",
        cta_subtitle: "Schedule a free meeting with our team of experts",
        cta_button: "Schedule a free meeting",
        
        // Footer
        footer_tagline: "We transform data into strategic decisions",
        footer_nav: "Navigation",
        footer_contact: "Contact",
        footer_legal: "Legal",
        footer_privacy: "Privacy Policy",
        footer_service: "Service Policy",
        footer_terms: "Terms and Conditions",
        footer_rights: "All rights reserved.",
        
        // Services Page
        services_page_title: "Our Services",
        services_page_subtitle: "Data analysis solutions designed to drive your company's growth",
        services_detail1_title: "Interactive Dashboards",
        services_detail1_desc: "Customized and easy-to-use control panels that transform complex data into clear and intuitive visualizations. They enable instant understanding of your business status and facilitate informed real-time decisions.",
        services_detail2_title: "Automated Reports",
        services_detail2_desc: "Automatically generated reports that save you time and reduce errors. Receive detailed and accurate reports in your inbox periodically, allowing constant performance monitoring without manual effort.",
        services_detail3_title: "Trend Analysis",
        services_detail3_desc: "Identify hidden patterns in your historical data to anticipate market trends. Our deep analyses reveal growth opportunities and help you make proactive strategic decisions rather than reactive ones.",
        services_detail4_title: "Visualized KPIs",
        services_detail4_desc: "Measure your business success with clear, understandable, and actionable key performance indicators. We transform complex metrics into visualizations that instantly communicate your company's status and facilitate strategic decisions.",
        
        // Portfolio Page
        portfolio_title: "Success Stories",
        portfolio_subtitle: "Discover how we have helped companies transform their data",
        portfolio1_category: "Retail",
        portfolio1_title: "Sales and Billing Dashboard",
        portfolio1_desc: "Implementation of a complete sales analysis system for a retail chain.",
        portfolio2_category: "Finance",
        portfolio2_title: "Executive Financial Control",
        portfolio2_desc: "Executive dashboard for comprehensive financial analysis.",
        portfolio3_category: "Marketing",
        portfolio3_title: "Digital Marketing Analytics",
        portfolio3_desc: "Integration of data from multiple digital platforms.",
        testimonials_title: "What our clients say",
        
        // Contact Page
        contact_title: "Contact Us",
        contact_subtitle: "We are here to help you transform your data",
        contact_form_title: "Send us a message",
        contact_name: "Full name",
        contact_email: "Email",
        contact_phone: "Phone",
        contact_message: "Message",
        contact_submit: "Send message",
        contact_info_title: "Contact information",
        
        // Policies Page
        policies_title: "Policies and Legal Documents",
        policies_subtitle: "Transparency and commitment to our clients",
        policies_intro_title: "Legal Documentation",
        policies_intro_desc: "At D&J Insights Group we are committed to transparency and legal compliance. Below, you can consult and download our official documents:",
        policy1_title: "Service Policies",
        policy1_desc: "Learn about our terms of service, project scope, delivery times, and commitments to our clients.",
        policy2_title: "Privacy Policies",
        policy2_desc: "Information about how we collect, use, and protect your personal data in accordance with current regulations.",
        policy3_title: "Terms and Conditions",
        policy3_desc: "Legal terms governing the use of our services, obligations of both parties, and conflict resolution.",
        download_pdf: "Download PDF",
        policies_summary: "Summary of Our Policies",
        
        // About Page
        about_page_title: "About Us",
        about_page_subtitle: "Meet the team behind D&J Insights Group",
        about_story_title: "Who are we?",
        about_story_p1: "We are a <strong>team of data-passionate experts</strong>, dedicated to excellence in every project we undertake. We specialize in turning complex data challenges into clear and actionable opportunities that drive sustainable growth for your business.",
        about_story_p2: "We offer <strong>customized data analysis and visualization solutions</strong>, from interactive dashboards to executive reports, specifically designed to meet each client's unique needs.",
        about_story_p3: "Our <strong>collaborative approach</strong> allows us to seamlessly integrate with your team, deeply understanding your industry and objectives to deliver solutions that truly generate impact.",
        about_pillars_title: "Our Pillars",
        why_choose_title: "Why choose us?",
        reason1_title: "Dedicated Experts",
        reason1_desc: "A specialized team passionate about data, committed to excellence in every project and constantly updating their knowledge.",
        reason2_title: "Unwavering Support",
        reason2_desc: "We don't just deliver the project, we accompany you afterwards to ensure you get the most out of it.",
        reason3_title: "Cutting-Edge Technology",
        reason3_desc: "We use the most advanced tools in data analysis to prepare our clients for the digital future.",
        reason4_title: "Customized Solutions",
        reason4_desc: "Every company is unique. We design solutions specifically adapted to your objectives, industry, and particular challenges.",
        reason5_title: "Measurable Impact",
        reason5_desc: "Every solution we implement generates quantifiable results that improve your organization's performance and growth.",
    }
};

// Language Management
let currentLang = localStorage.getItem('language') || 'es';

// Initialize language on page load
document.addEventListener('DOMContentLoaded', () => {
    setLanguage(currentLang);
    updateLanguageDropdown();
    
    // Dropdown toggle functionality
    const dropdownBtn = document.getElementById('langDropdownBtn');
    const dropdownMenu = document.getElementById('langDropdownMenu');
    
    if (dropdownBtn && dropdownMenu) {
        // Toggle dropdown
        dropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdownMenu.classList.toggle('active');
            dropdownBtn.classList.toggle('active');
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!dropdownBtn.contains(e.target) && !dropdownMenu.contains(e.target)) {
                dropdownMenu.classList.remove('active');
                dropdownBtn.classList.remove('active');
            }
        });
        
        // Language selection
        document.querySelectorAll('.lang-option').forEach(option => {
            option.addEventListener('click', () => {
                const lang = option.getAttribute('data-lang');
                setLanguage(lang);
                localStorage.setItem('language', lang);
                updateLanguageDropdown();
                dropdownMenu.classList.remove('active');
                dropdownBtn.classList.remove('active');
            });
        });
    }
});

function updateLanguageDropdown() {
    const currentFlag = document.getElementById('currentFlag');
    const currentLangCode = document.getElementById('currentLang');
    
    if (currentFlag && currentLangCode) {
        if (currentLang === 'es') {
            currentFlag.textContent = '🇨🇴';
            currentLangCode.textContent = 'ES';
        } else {
            currentFlag.textContent = '🇺🇸';
            currentLangCode.textContent = 'EN';
        }
    }
    
    // Update active state in dropdown options
    document.querySelectorAll('.lang-option').forEach(option => {
        option.classList.remove('active');
        if (option.getAttribute('data-lang') === currentLang) {
            option.classList.add('active');
        }
    });
}

function setLanguage(lang) {
    currentLang = lang;
    
    // Update all elements with data-translate attribute
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (translations[lang] && translations[lang][key]) {
            if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                element.placeholder = translations[lang][key];
            } else {
                element.innerHTML = translations[lang][key];
            }
        }
    });

    // Keep theme toggle label in sync with the selected language
    if (typeof window.updateThemeToggleLabel === 'function') {
        window.updateThemeToggleLabel();
    }
}
