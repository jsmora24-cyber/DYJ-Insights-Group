// Theme (Light / Dark)
const THEME_STORAGE_KEY = 'theme';

function getStoredTheme() {
    try {
        return localStorage.getItem(THEME_STORAGE_KEY);
    } catch {
        return null;
    }
}

function getSystemTheme() {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light';
}

function getInitialTheme() {
    return getStoredTheme() || getSystemTheme();
}

function applyTheme(theme) {
    const safeTheme = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', safeTheme);
    document.documentElement.style.colorScheme = safeTheme;
}

function getTranslationValue(lang, key, fallback) {
    try {
        if (typeof translations !== 'undefined' && translations[lang] && translations[lang][key]) {
            return translations[lang][key];
        }
    } catch {
        // ignore
    }
    return fallback;
}

function updateThemeToggleLabel() {
    const themeToggleInput = document.getElementById('themeToggle');
    const themeMenuBtn = document.getElementById('themeMenuBtn');
    if (!themeMenuBtn) return;

    const isDark = (themeToggleInput && themeToggleInput.checked) || document.documentElement.getAttribute('data-theme') === 'dark';
    const labelKey = isDark ? 'theme_dark' : 'theme_light';
    const lang = localStorage.getItem('language') || 'es';
    const fallback = labelKey === 'theme_dark' ? 'Modo oscuro' : 'Modo claro';
    const label = getTranslationValue(lang, labelKey, fallback);

    themeMenuBtn.setAttribute('aria-label', label);
    themeMenuBtn.setAttribute('title', label);
}

window.updateThemeToggleLabel = updateThemeToggleLabel;

function syncThemeMenuSelection(theme) {
    document.querySelectorAll('.theme-menu-item[data-theme]').forEach((btn) => {
        btn.classList.toggle('is-active', btn.dataset.theme === theme);
    });
}

function setTheme(theme) {
    const safeTheme = theme === 'dark' ? 'dark' : 'light';
    applyTheme(safeTheme);
    try {
        localStorage.setItem(THEME_STORAGE_KEY, safeTheme);
    } catch {
        // ignore
    }

    const themeToggleInput = document.getElementById('themeToggle');
    if (themeToggleInput) {
        themeToggleInput.checked = safeTheme === 'dark';
    }
    syncThemeMenuSelection(safeTheme);
    updateThemeToggleLabel();
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    setTheme(currentTheme === 'dark' ? 'light' : 'dark');
}

window.toggleTheme = toggleTheme;

// Apply theme as early as possible
applyTheme(getInitialTheme());

// If the toggle exists, sync its initial checked state
document.addEventListener('DOMContentLoaded', () => {
    const initialTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
    const themeToggleInput = document.getElementById('themeToggle');
    if (themeToggleInput) {
        themeToggleInput.checked = initialTheme === 'dark';
        themeToggleInput.addEventListener('change', () => {
            setTheme(themeToggleInput.checked ? 'dark' : 'light');
        });
    }

    // Gear dropdown options
    const themeMenu = document.getElementById('themeMenu');
    document.querySelectorAll('.theme-menu-item[data-theme]').forEach((btn) => {
        btn.addEventListener('click', () => {
            setTheme(btn.dataset.theme);
            if (themeMenu) themeMenu.open = false;
        });
    });

    // Close theme menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!themeMenu || !themeMenu.open) return;
        if (!themeMenu.contains(e.target)) themeMenu.open = false;
    });

    // Close theme menu on Escape
    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape') return;
        if (themeMenu && themeMenu.open) themeMenu.open = false;
    });

    // Initial active state
    syncThemeMenuSelection(initialTheme);
});

// Initialize label once DOM is ready (safe for all pages)
document.addEventListener('DOMContentLoaded', () => {
    updateThemeToggleLabel();
});

// Mobile Menu Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
}

// Close menu when clicking on a link
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        if (navMenu) navMenu.classList.remove('active');
        if (hamburger) hamburger.classList.remove('active');
    });
});

// Header scroll effect
let lastScroll = 0;
const header = document.querySelector('.header');

function isDarkModeActive() {
    const htmlTheme = document.documentElement.getAttribute('data-theme');
    if (htmlTheme === 'dark') return true;
    const themeToggleInput = document.getElementById('themeToggle');
    return !!(themeToggleInput && themeToggleInput.checked);
}

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (header) {
        const dark = isDarkModeActive();
        if (currentScroll > 100) {
            header.style.boxShadow = dark
                ? '0 10px 30px rgba(0, 0, 0, 0.45)'
                : '0 2px 20px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.boxShadow = dark
                ? '0 6px 18px rgba(0, 0, 0, 0.30)'
                : '0 2px 10px rgba(0, 0, 0, 0.1)';
        }
    }
    
    lastScroll = currentScroll;
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && href.length > 1) {
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// Scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', () => {
    const animateElements = document.querySelectorAll('.service-card, .value-card, .about-content');
    
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
});

// Pre-select plan from URL parameter
if (window.location.pathname.includes('contacto.html') || window.location.pathname.endsWith('/contacto')) {
    const urlParams = new URLSearchParams(window.location.search);
    const planParam = urlParams.get('plan');
    
    if (planParam) {
        const serviceSelect = document.getElementById('service');
        if (serviceSelect) {
            serviceSelect.value = planParam;
            // Add a highlight effect to show it was pre-selected
            serviceSelect.style.borderColor = 'var(--primary-color)';
            serviceSelect.style.boxShadow = '0 0 0 3px rgba(0, 166, 232, 0.1)';
            setTimeout(() => {
                serviceSelect.style.borderColor = '';
                serviceSelect.style.boxShadow = '';
            }, 2000);
        }
    }
}

// Contact Form Handler (for contacto.html)
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formStatus = document.getElementById('formStatus');
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Show loading state
        submitBtn.textContent = 'Enviando...';
        submitBtn.disabled = true;
        formStatus.textContent = '';
        formStatus.className = 'form-status';
        
        try {
            const formData = new FormData(contactForm);
            const response = await fetch(contactForm.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (response.ok) {
                formStatus.textContent = '¡Mensaje enviado con éxito! Te contactaremos pronto.';
                formStatus.className = 'form-status success';
                contactForm.reset();
            } else {
                throw new Error('Error en el envío');
            }
        } catch (error) {
            formStatus.textContent = 'Hubo un error al enviar el mensaje. Por favor, intenta de nuevo o contáctanos por WhatsApp.';
            formStatus.className = 'form-status error';
        } finally {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }
    });
}

// Scroll indicator hide on scroll
const scrollIndicator = document.querySelector('.scroll-indicator');
if (scrollIndicator) {
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 100) {
            scrollIndicator.style.opacity = '0';
        } else {
            scrollIndicator.style.opacity = '1';
        }
    });
}

// Image Modal for Portfolio
function openImageModal(src, alt) {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const caption = document.getElementById('modalCaption');
    
    if (modal && modalImg) {
        modal.style.display = 'flex';
        modalImg.src = src.replace('w=800', 'w=1920'); // Load higher resolution
        caption.innerHTML = alt;
        document.body.style.overflow = 'hidden'; // Prevent scrolling
    }
}

function closeImageModal() {
    const modal = document.getElementById('imageModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto'; // Restore scrolling
    }
}

// Close modal with Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeImageModal();
    }
});
